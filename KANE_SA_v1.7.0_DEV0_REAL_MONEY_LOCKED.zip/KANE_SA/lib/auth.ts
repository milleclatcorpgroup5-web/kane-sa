import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';

export async function requireUser() {
  const supabase = await createClient();
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) redirect('/connexion');
  return { supabase, user };
}

export async function requireRole(roles: string[]) {
  const { supabase, user } = await requireUser();
  const { data: profile } = await supabase.from('profiles').select('role, full_name').eq('id', user.id).maybeSingle();
  if (!profile || !roles.includes(profile.role)) redirect('/tableau-de-bord');
  return { supabase, user, profile };
}
