import { createBrowserClient } from '@supabase/ssr';
import type { Database } from './database.types';

export function createClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) throw new Error('Supabase pa konfigire. Mete NEXT_PUBLIC_SUPABASE_URL ak NEXT_PUBLIC_SUPABASE_ANON_KEY.');
  return createBrowserClient<Database>(url, key);
}
